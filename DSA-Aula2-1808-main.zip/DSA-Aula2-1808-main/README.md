# DSA-Aula2-1808
Aula 2 de Desenvolvimento de Serviços e APIs - Primevideo - 18/08
